-- CaseProof Enterprise v3.0 PROPOSED PostgreSQL 16 DDL (not deployed)
-- Synthetic/demo architecture. Reviewed migrations, RLS, KMS, WORM storage are not implemented here.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE tenant (
 tenant_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), code text UNIQUE NOT NULL,
 display_name text NOT NULL, enabled boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE workflow_pack (
 pack_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 workflow_key text NOT NULL, version text NOT NULL, config jsonb NOT NULL,
 manifest_sha256 char(64) NOT NULL, approved_at timestamptz,
 UNIQUE(tenant_id, workflow_key, version)
);
CREATE TABLE insurance_product (
 product_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 product_code text NOT NULL, product_kind text NOT NULL CHECK (product_kind IN ('LIFE','NON_LIFE')),
 UNIQUE(tenant_id, product_code)
);
CREATE TABLE policy_source (
 source_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 product_id uuid NOT NULL REFERENCES insurance_product, source_uri text,
 source_name text NOT NULL, sha256 char(64) NOT NULL,
 trust_state text NOT NULL CHECK (trust_state IN ('QUARANTINED','DRAFT','PENDING_REVIEW','PUBLISHED','REVOKED')),
 recorded_at timestamptz NOT NULL DEFAULT now(), published_at timestamptz,
 parser_version text, UNIQUE(tenant_id, sha256)
);
CREATE TABLE policy_rule_revision (
 rule_revision_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tenant_id uuid NOT NULL REFERENCES tenant, product_id uuid NOT NULL REFERENCES insurance_product,
 source_id uuid NOT NULL REFERENCES policy_source, rule_key text NOT NULL,
 rider_code text, date_basis text NOT NULL CHECK (date_basis IN ('contract_start_date','incident_date','claim_received_date','question_date')),
 valid_from date NOT NULL, valid_to date NOT NULL,
 recorded_from timestamptz NOT NULL, recorded_to timestamptz NOT NULL,
 priority integer NOT NULL DEFAULT 0, rule_body jsonb NOT NULL,
 clause_key text NOT NULL, clause_span jsonb NOT NULL,
 revision_sha256 char(64) NOT NULL,
 CHECK (valid_from < valid_to), CHECK (recorded_from < recorded_to)
);
CREATE INDEX idx_rule_resolver ON policy_rule_revision(tenant_id,product_id,rule_key,date_basis,valid_from,valid_to,priority DESC);
CREATE TABLE case_record (
 case_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 product_id uuid NOT NULL REFERENCES insurance_product,
 workflow_key text NOT NULL, context jsonb NOT NULL, context_sha256 char(64) NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE answer_revision (
 answer_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 case_id uuid NOT NULL REFERENCES case_record,
 previous_answer_id uuid REFERENCES answer_revision,
 body text NOT NULL, body_sha256 char(64) NOT NULL,
 ai_system_ref text, model_ref text, prompt_sha256 char(64),
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE evaluation_run (
 run_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 answer_id uuid NOT NULL REFERENCES answer_revision,
 run_status text NOT NULL CHECK (run_status IN ('QUEUED','RUNNING','COMPLETED','FAILED','CANCELLED')),
 verdict text CHECK (verdict IN ('PASS','REVIEW','BLOCK','INCONCLUSIVE')),
 error_code text, config_snapshot_sha256 char(64) NOT NULL,
 dataset_snapshot_id text, evaluator_sha256 char(64),
 started_at timestamptz, completed_at timestamptz,
 CHECK ((run_status='COMPLETED' AND verdict IS NOT NULL) OR (run_status<>'COMPLETED' AND verdict IS NULL))
);
CREATE TABLE evaluation_finding (
 finding_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 run_id uuid NOT NULL REFERENCES evaluation_run,
 rule_revision_id uuid REFERENCES policy_rule_revision,
 severity text NOT NULL CHECK (severity IN ('CRITICAL','MAJOR','MINOR','INFO')),
 reason_code text NOT NULL, claim_span jsonb, evidence_span jsonb,
 explanation text NOT NULL
);
CREATE TABLE change_set (
 change_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 change_type text NOT NULL CHECK (change_type IN ('POLICY','PROMPT','MODEL','RETRIEVAL','CODE','TOOL_PERMISSION')),
 old_sha256 char(64), new_sha256 char(64) NOT NULL,
 status text NOT NULL DEFAULT 'DRAFT', requester_id text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE impact_edge (
 edge_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 from_type text NOT NULL, from_key text NOT NULL, to_type text NOT NULL, to_key text NOT NULL,
 map_revision text NOT NULL,
 UNIQUE(tenant_id,from_type,from_key,to_type,to_key,map_revision)
);
CREATE TABLE dataset_snapshot (
 snapshot_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 name text NOT NULL, sha256 char(64) NOT NULL,
 sealed_at timestamptz NOT NULL DEFAULT now(), UNIQUE(tenant_id,sha256)
);
CREATE TABLE experiment_run (
 experiment_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 change_id uuid REFERENCES change_set,
 dataset_snapshot_id uuid NOT NULL REFERENCES dataset_snapshot,
 evaluator_sha256 char(64) NOT NULL,
 baseline_config_sha256 char(64) NOT NULL, candidate_config_sha256 char(64) NOT NULL,
 status text NOT NULL DEFAULT 'QUEUED', completed_at timestamptz
);
CREATE TABLE experiment_case_result (
 result_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 experiment_id uuid NOT NULL REFERENCES experiment_run,
 case_key text NOT NULL, side text NOT NULL CHECK (side IN ('BASELINE','CANDIDATE')),
 run_status text NOT NULL, verdict text,
 duration_ms integer, cost_units numeric(18,8),
 UNIQUE(experiment_id,case_key,side)
);
CREATE TABLE review_event (
 review_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 run_id uuid NOT NULL REFERENCES evaluation_run,
 action text NOT NULL CHECK (action IN ('APPROVE_FOR_INTERNAL_USE','REJECT','REQUEST_CHANGES')),
 actor_id text NOT NULL, previous_version integer NOT NULL,
 reason text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE release_candidate (
 release_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenant,
 experiment_id uuid NOT NULL REFERENCES experiment_run,
 status text NOT NULL CHECK (status IN ('DRAFT','TESTING','BLOCKED','PENDING_APPROVAL','APPROVED_FOR_DEMO','REVOKED')),
 requester_id text NOT NULL, approver_id text,
 expected_version integer NOT NULL DEFAULT 0, check_report jsonb,
 created_at timestamptz NOT NULL DEFAULT now(),
 CHECK (approver_id IS NULL OR approver_id <> requester_id)
);
CREATE TABLE audit_event (
 audit_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, tenant_id uuid NOT NULL REFERENCES tenant,
 event_type text NOT NULL, actor_id text NOT NULL,
 subject_kind text NOT NULL, subject_id text NOT NULL,
 occurred_at timestamptz NOT NULL DEFAULT now(),
 payload jsonb NOT NULL, prev_hash char(64), event_hash char(64) NOT NULL
);
CREATE INDEX idx_audit_tenant_subject ON audit_event(tenant_id,subject_kind,subject_id,audit_id);
-- SECURITY NOTE: require tenant checking on JOINed records; FKs alone do not prove same-tenant.
-- Production migration must add RLS, security-barrier views, per-tenant audit hash chain,
-- immutable audit trigger/storage, reviewed retention rules, and out-of-DB hash anchoring.
