"""Static spec sanity checks; PyYAML optional but used if present."""
from pathlib import Path
import json, re, sys
root=Path(__file__).resolve().parents[1]
errors=[]
for file in ('contracts/openapi.v1.yaml','contracts/core.sql','datasets/resolver_test_cases.json',
             'datasets/synthetic_rules.json','docs/09_정본_충돌해소_개발선행조건.md'):
    if not (root/file).exists(): errors.append('MISSING '+file)
for banned in ('contracts/openapi.yaml','contracts/schema.sql','reference/policy_resolver.py'):
    if (root/banned).exists(): errors.append('DUPLICATED CANONICAL '+banned)
for path in (root/'datasets').glob('*.json'):
    try: json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc: errors.append(f'INVALID JSON {path.name}: {exc}')
try:
    import yaml
    spec=yaml.safe_load((root/'contracts/openapi.v1.yaml').read_text(encoding='utf-8'))
    ops=set()
    for endpoints in spec['paths'].values():
        for method, d in endpoints.items():
            if method.lower() in ('get','post','put','patch','delete'):
                name=d.get('operationId')
                if name in ops: errors.append('DUPLICATED operationId '+str(name))
                ops.add(name)
    must={'getWorkspace','listSources','createSource','publishSource','resolvePolicy',
          'createEvaluation','evaluateAnswer','getJob','reviewRun','createChange',
          'buildImpact','compareExperiments','checkRelease','approveRelease',
          'setKillSwitch','exportAudit'}
    for missing in must-ops: errors.append('MISSING operationId '+missing)
except ImportError:
    print('YAML parser not installed: skipped OpenAPI parse check')
except Exception as exc: errors.append('OpenAPI parse failed: '+str(exc))
if errors:
    print('\n'.join(errors)); sys.exit(1)
print('STATIC CONTRACT CHECK: PASS')
