"""Run from root: python -m reference.demo"""
from .verify_answer import verify_numeric_claim
req={'tenant':'AURORA_NONLIFE','product':'AUTO-101','workflow':'AUTO_CLAIM_GUIDANCE',
     'rule_key':'DOCUMENT_WINDOW_DAYS','claim_received_date':'2026-06-20',
     'as_of_recorded':'2026-10-28T00:00:00+09:00'}
print('AI (wrong latest) 20 days =>',verify_numeric_claim(req,20))
print('AI (correct old)  30 days =>',verify_numeric_claim(req,30))
