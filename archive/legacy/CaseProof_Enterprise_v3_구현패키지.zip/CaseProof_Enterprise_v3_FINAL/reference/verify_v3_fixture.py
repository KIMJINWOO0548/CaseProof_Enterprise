"""Verify 20 v3 synthetic resolver examples. Not a full model benchmark."""
from pathlib import Path
import json
from resolver import resolve

ROOT = Path(__file__).resolve().parents[1]
fixture = json.loads((ROOT / 'datasets' / 'resolver_test_cases.json').read_text(encoding='utf-8'))
failed = []
for case in fixture['cases']:
    query = dict(case['input'])
    query.setdefault('as_of_recorded', fixture['default_recorded'])
    result = resolve(query)
    expected = case['expected']
    ok = result.status == expected['status']
    if 'rule_id' in expected: ok &= result.rule_id == expected['rule_id']
    if 'value' in expected: ok &= result.value == expected['value']
    if 'reason' in expected: ok &= expected['reason'] in result.reason_codes
    if not ok: failed.append(case['id'])
    print(f"{'PASS' if ok else 'FAIL'} {case['id']} status={result.status} reason={result.reason_codes}")
print(f"RESULT {len(fixture['cases'])-len(failed)}/{len(fixture['cases'])} synthetic reference fixtures passed")
if failed: raise SystemExit(1)
