# CaseProof Enterprise v4 local synthetic verification (Windows PowerShell)
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Push-Location $root
try {
  python -m unittest discover -s tests -v
  if ($LASTEXITCODE -ne 0) { throw 'Unit tests failed' }
  python reference/verify_v3_fixture.py
  if ($LASTEXITCODE -ne 0) { throw 'Synthetic fixture test failed' }
  python -m reference.demo
  if ($LASTEXITCODE -ne 0) { throw 'Demo failed' }
  python reference/check_contracts.py
  if ($LASTEXITCODE -ne 0) { throw 'Static contracts failed' }
  python scripts/verify_manifest.py
  if ($LASTEXITCODE -ne 0) { throw 'Manifest verification failed' }
  Write-Host 'PASS: synthetic reference checks only (not production insurance validation).'
}
finally { Pop-Location }
