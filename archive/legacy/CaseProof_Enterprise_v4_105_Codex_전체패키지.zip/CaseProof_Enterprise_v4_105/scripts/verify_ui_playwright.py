"""Optional local UI smoke test. Requires: pip install playwright, Chromium."""
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=ROOT/'demo'/'CaseProof_Enterprise_오프라인_UI_시연.html'
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True)
    page=browser.new_page(viewport={'width': 1440,'height':900})
    page.set_content(HTML.read_text(encoding='utf-8'), wait_until='load')
    assert page.locator('#criticalKpi').inner_text()=='1'
    page.locator('[data-panel="cases"]').click();page.locator('#fix').click()
    page.locator('#requestReview').click()
    page.locator('#actor').select_option('domain');page.locator('#domainApprove').click()
    page.locator('#actor').select_option('approver');page.locator('#approve').click()
    assert page.locator('#releaseStatus').inner_text()=='APPROVED_FOR_DEMO'
    page.locator('[data-panel="audits"]').click()
    assert '데모 배포 승인' in page.locator('#fullLog').inner_text()
    browser.close()
print('PASS synthetic frontend user-flow; not production auth or AI test')
