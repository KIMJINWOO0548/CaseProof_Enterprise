"""Recompute hashes of an exported package against a manifest, stdlib only."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1]
MANIFEST=ROOT/'evidence'/'file_manifest_v4_sha256.json'

def verify():
  mapping=json.loads(MANIFEST.read_text(encoding='utf-8'))['files']
  errors=[]
  for key,expected in mapping.items():
    p=ROOT/key
    if not p.is_file():errors.append(f'MISSING {key}');continue
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    if actual!=expected:errors.append(f'CHANGED {key}')
  return errors
if __name__=='__main__':
  fails=verify()
  for f in fails: print(f)
  print(f'MANIFEST CHECK: {"FAIL" if fails else "PASS"}')
  sys.exit(1 if fails else 0)
