# 데이터·API·이벤트·트랜잭션 상세 정본 v4 (설계 단계)

## 1. 불변식(Invariants)

**INV-01:** 모든 업무 객체는 서버 인증 actor에서 결정된 `tenant_id`와 일치해야 한다. 사용자 JSON의 `tenant_id`는 권한을 부여하지 않는다.

**INV-02:** 타사 데이터 참조를 금지한다. `case_record.tenant_id`, `insurance_product.tenant_id`, `answer_revision.tenant_id`, `evaluation_run.tenant_id`, `policy_rule_revision.tenant_id`, `policy_source.tenant_id` 간 복합 FK를 설정하고 RLS로 실험한다. 'tenant_id 컬럼 존재'만으로 격리 성공이라 보지 않는다.

**INV-03:** 문서 `PUBLISHED` 이전에 추출된 규칙의 `source_id`는 판정에 쓸 수 없다. `REVOKED`는 과거 기록 삭제 대신 재검토 트리거.

**INV-04:** 모든 기준 시간은 타임존을 가진 UTC 순간과 로컬 업무 날짜로 구분한다. `recorded_from <= as_of_recorded < recorded_to`와 `valid_from <= basis_date < valid_to`를 동시에 만족해야 한다.

**INV-05:** `rule_revision`은 원문 조항 스팬을 가진다. 스팬 손실·원문 해시 변경 시 `INCONCLUSIVE`, 안전한 자동 보정 금지.

**INV-06:** `release_id`와 승인 이벤트는 반드시 **동일 evidence manifest SHA-256**을 참조한다. 버전/데이터가 바뀌면 기존 승인은 무효다.

**INV-07:** 담당자가 `APPROVE`를 누를 때 최신 revision을 조건부 업데이트해 단일 성공을 보장한다(optimistic lock + transaction). 중복 클릭 멱등.

**INV-08:** 저장된 평가의 출처·모델·프롬프트·데이터셋·판정자 버전은 재계산 없이 식별 가능하고, 재실행과 결과 비교가 가능해야 한다.

**INV-09:** 규정 편집자는 자신의 편집을 최종 게시할 수 없다. 배포 요청자는 배포 승인자일 수 없다.

**INV-10:** 감사 이벤트에 원본 의료/식별 데이터·비밀키·LLM 원문 전문을 기본 기록하지 않는다.

## 2. 핵심 데이터 모델 추가/변경 요구

기존 `contracts/core.sql`은 설계 초안이다. 다음이 실제 migration에서 보완되어야 한다.

| 엔터티 | 추가 필드/제약 | 주목적 |
|---|---|---|
| `policy_source` | content_type, parser_revision, latest_review_id, quarantine_reason | 문서 출처와 추출 책임 |
| `policy_rule_revision` | `recorded_to` exclusive, structured condition, explicit precedence, span hash | 시간별 재현·우선순위 |
| `case_record` | fake_customer_key, retention_class, PII scrub status | 테스트 안전성 |
| `workflow_pack` | YAML schema version, signed manifest, compatibility version | 보험사별 업무확장 검증 |
| `evaluation_run` | trigger_request_id, input snapshot, source snapshot, attempt, evaluator version | 재실행·중복 방지 |
| `experiment_run` | cohort, seed, frozen dataset hash, pair mapping, evaluator SHA | 비교 공정성 |
| `release_candidate` | domain approval ID, risk approval ID, manifest SHA, CAS revision | 다자 승인·최신성 |
| `audit_event` | action basis, payload redaction version, actor scope, anchored digest ID | 감사 위험 낮추기 |
| `outbox_event` | job ID, idempotency key, attempt, last_error, next_retry_at | DB+비동기 메시지 일관성 |

참조 스키마 SQL의 단일 UUID FK는 **교차 테넌트 참조를 막지 못한다**. 실제 Migration에서는 예를 들어 `(tenant_id, product_id)` UNIQUE와 `(tenant_id, product_id)` 복합 FK를 모든 연관 관계에 일관되게 적용하고, API 보안 테스트와 Postgres RLS 테스트를 병행해야 한다. 여기서는 실제 DB 서버 실행/검증을 했다고 주장하지 않는다.

## 3. API 계약 변경 후보 (v4 확장; 미구현)

모든 응답은 `{request_id, status, data, error:{code,message,retryable}}` 형태. `OpenAPI v3.1` 신규 버전 정의 전에는 기존 `contracts/openapi.v1.yaml`이 유일한 실행 계약이며, 이 표는 후속 계약 변경 요청 목록이다.

| Method | Route | 주체 | 요점 | 실패 상태 |
|---|---|---|---|---|
| POST | `/v1/source-ingestions` | 상품 담당자 | 허용된 문서 스캔·수신·추출 | 202, 413, 422, 409 |
| POST | `/v1/source-revisions/{id}/submit` | 작성자 | 검수 요청 + 최신 버전 | 409, 422 |
| POST | `/v1/source-revisions/{id}/publish` | 별도 검수자 | 출처·날짜·조항 승인 | 403, 409, 422 |
| POST | `/v1/cases` | 업무분석가 | 합성 사례 등록, idempotency | 201, 409, 422 |
| POST | `/v1/evaluations` | 업무분석가 | 평가 요청 + 입력/정본 snapshot | 202, 409, 422 |
| GET | `/v1/evaluations/{id}` | 같은 테넌트 사용자 | 완료/진행/실패/불확실 | 200, 403, 404 |
| POST | `/v1/changes/{id}/impact` | DX PM | 테스트 후보 + 누락 노드 | 202, 409 |
| POST | `/v1/experiments` | AI 개발자 | baseline/candidate paired run | 202, 422 |
| POST | `/v1/releases/{id}/reviews` | 검토자 | 도메인·위험 검토 기록 | 201, 403, 409 |
| POST | `/v1/releases/{id}/decisions` | 승인자 | If-Match / manifest hash 필수 | 200, 403, 409, 422 |
| POST | `/v1/releases/{id}/revoke` | 권한자 | 운영 연계 중단 신호 | 202, 403 |
| GET | `/v1/evidence-bundles/{id}` | 감사자 | 검증된 비식별 증거 ZIP | 200, 403, 423 |

### `POST /v1/releases/{id}/decisions` 예시 (제안 계약)

```json
{
  "action": "APPROVE_FOR_DEMO",
  "expected_revision": 5,
  "evidence_sha256": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
  "reason_code": "REVIEW_COMPLETE",
  "reason_text": "합성 시나리오의 필수 테스트와 승인 절차 검토 완료"
}
```

서버의 처리 순서는 인증 확인 → 역할·테넌트 확인 → 소유자/요청자 분리 확인 → 상태·revision·manifest CAS 확인 → 필수 검사 완료 확인 → 트랜잭션 update + 감사 이벤트/outbox 기록 → 성공 응답. `409`라면 현재 최신 상태를 다시 조회하고 사용자에게 재검토 요청한다.

## 4. 이벤트 처리와 멱등 계약

- 사건명: `policy.published`, `rule.revoked`, `case.received`, `eval.completed`, `change.impact_ready`, `release.approved`, `release.revoked`.
- 이벤트 Envelope: `{event_id, event_type, tenant_id, aggregate_id, aggregate_revision, emitted_at, payload_hash, correlation_id, schema_version}`.
- 동일 `event_id` 2회 수신은 최대 1회 처리; 서로 다른 ID의 같은 요청은 업무 멱등키로 중복 제거.
- Outbox 행과 비즈니스 변경을 **같은 DB 트랜잭션**에 저장하고 워커가 전달. 실패/재시도는 지수 백오프+상한+DLQ.
- 데이터셋, 규정, 평가자의 hash가 하나라도 바뀌면 비교 실험은 이전 결과와 함께 쓸 수 없음; 새로운 실험 생성.
- 장기 작업 취소/재실행은 이미 승인된 결과에 영향주지 않는 별도 실행 버전으로 남김.

## 5. 관측성과 성능 목표 (실측 아님)

- P95 UI 조회: 1.5초 이하, 단 **일반 검색/작업함 조회**의 목표. LLM 평가 완료 시간과 혼동하지 않음.
- 오류/실패율: 요청 5xx 비율, 큐 backlog, orphan job, authorization denies, stale approval conflict, hash-verification fail를 각각 집계.
- 로그 상관관계: tenant-scoped `correlation_id`→`case_id`→`evaluation_run_id`→`release_candidate_id`; 민감 원문 대신 식별자·해시 저장.
- 예산: 모델당 입력/출력 토큰·실행 비용·직원 검토 시간·저장/백업 비용을 분리 계측. 예산 초과 시 새로운 작업은 HOLD, 이미 접수된 중단 불가 업무는 안전 정책에 따라 처리.
- 가용성 장애 시 **Fail closed**: 증거를 못 읽거나 검증 엔진이 실패하면 운영 승인 자동 차단, 원인·재시도 안내만 제공.

## 6. 변경 영향 그래프의 정확성

- 노드: `source`, `clause`, `rule_revision`, `workflow_pack`, `retriever_index`, `prompt`, `model`, `evaluation_case`, `release_candidate`.
- 간선 유형: `contains`, `interpreted_by`, `used_in`, `evaluated_by`, `depends_on`.
- 갱신: 새 조항 등록 시 기존 조항과의 `supersedes` 관계 생성. 삭제는 tombstone.
- 테스트 선택: 영향받은 테스트 + sentinel + 과거 치명적 실패 + coverage hole 보완. 그래프에 맵핑이 없으면 `UNKNOWN_IMPACT`, 자동 '영향 없음' 결론 금지.
- 반례: 간선 누락·순환·교차 tenant·중복 test ID·수정과 동시에 병행 실행·승인 직전 재수정.
- 성능: 작은 데이터셋부터 BFS로 구현; 규모 증명 전 Graph DB 도입 금지.
