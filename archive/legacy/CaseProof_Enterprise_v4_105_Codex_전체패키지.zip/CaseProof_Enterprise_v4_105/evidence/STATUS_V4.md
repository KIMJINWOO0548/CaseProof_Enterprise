# v4 실행 현황 / 증거 등급

- **테스트 재현**: `python -m unittest discover -s tests -v` — 49 tests, OK, Python 표준 라이브러리, 합성 코드.
- **추가 검증**: `reference/verify_v3_fixture.py`·`reference.demo`·`reference/check_contracts.py` 실행 로그 각각 저장.
- **구현 완료**: 결정론적 약관 resolver/변경영향/릴리스 demo gate(기존), 거버넌스 authorize/approval reference, SHA-256 manifest + in-memory chain reference, paired comparison stats reference(신규).
- **미구현**: 실제 FastAPI 서버, PostgreSQL/마이그레이션/RLS, React UI, 인증/세션, 실 LLM/RAG, 서명·외부 hash anchor, 회사별 E2E, 360 gold cases, 현업 사용자 시험.
- **법적 상태**: 금융위원회 가이드라인·금융보안원 보도자료 참고했으나 준수·인증 또는 실제 금융사 사용 승인 없음.
- **평가**: 76/100 +0/5. 외부 평가가 아닌 코드·명세 진척도 자체 추적. 증거 기준은 `score/16_RUBRIC_105.md`.
- **근거 이슈**: 금융보안원 발표문 요약 `6개 분야·17개 항목` vs 본문 분류 표 `1~5번`. 보도기사 5개라고 보도된 사례도 있음. 출처 우선순위: 공식 원문, 해석 불일치 기록.

## 추가 UI 시연 검증 (합성 브라우저, 백엔드 없는 프로토타입)

- `demo/CaseProof_Enterprise_오프라인_UI_시연.html`: 외부 네트워크 없이 열 수 있는 단일 HTML/CSS/JS 시연.
- Chromium/Playwright `page.set_content` 방식으로 확인: 작업함 이동→합성 답변 정정→검토 요청→별도 상품 검토자 역할 승인→별도 IT 승인자 역할 데모 승인→감사 이력 표시 **PASS**.
- 역할 전환은 프런트엔드 셀렉트 상자이므로 **인증 보안의 증거가 아니다**. 실제 승인 보안은 백엔드 구현과 E2E 필요.
