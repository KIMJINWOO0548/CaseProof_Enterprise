# Codex 단일 실행 지침 — CaseProof Enterprise v4 (105점 목표)

당신은 사내 개발팀 흉내를 내는 AI 에이전트가 아니라, **근거와 테스트를 갖춘 코드를 납품하는 구현자**다. 프롬프트만으로 완성됐다고 보고하지 말 것. 외부 제공 LLM/기술 사용량·비용을 실시간 확인하고 무한 루프를 피한다.

## 명령 0: 이미 존재하는 문서의 충돌 정본화

1. 최우선은 `README_V4.md`와 `specs/11_*`~`17_*`, `security/14_*`, `score/16_*`, 본 파일.
2. 구 v3 `docs/01~10`의 실험 데이터·기본 설계는 참조 자료다. API/DB는 기존 `contracts/openapi.v1.yaml`, `core.sql`을 **제안 초안**으로 취급하며, 새 버전 작성 전에는 실제 구현 정본을 선언하지 말 것.
3. 반드시 하나의 `IMPLEMENTATION_STATUS.md`에 `PLANNED/IMPLEMENTED/TESTED/EXTERNALLY_REVIEWED` 구분해 각 요구사항 최신 상태 기록.
4. 정보와 관련해 정본 충돌을 발견하면 스스로 추정해 숨기지 말고 `DECISIONS.md`에 선택 근거, 영향, 회귀 테스트를 남긴다.

## 순서대로 할 일 (한 게이트 통과 시 다음 단계)

**Gate 0 — 베이스라인 검사**
- Python unittest, JSON schemas, 기존 synthetic resolver fixture를 실제 실행. 실패는 오류 원문과 재현 명령 기록.
- 신규 `reference/governance.py`, `evidence_pack.py`, `paired_benchmark.py`는 참조 모듈이다. 프로덕션 서비스인 듯 부르지 말 것.
- 공식 금융보안원 보도자료 개요는 6개 분야·17개 항목(본문은 1~5 분류표)이며 17개 항목 이름이 원문에 있다. 원문을 근거로 정확하게 매핑하고 6/5 불일치 메타데이터를 기록할 것.

**Gate 1 — API + Postgres P0 slice**
- FastAPI, PostgreSQL, Alembic, pytest, httpx; DB·인증 후 tenant를 token에서 확보, 누락 tenant에 기본 접근 차단.
- v4 invariant INV-01~10을 DB migration+테스트에 연결. 복합 FK/RLS, 사용자 컨텍스트를 실제 연결 테스트해야 다음 게이트로 이동.
- 공통 오류 응답, idempotency key, UUID, correlation id, UTC timestamps 구현. 보안 로그의 개인정보 유출 검토.

**Gate 2 — 실무용 단일 사례 React UI**
- React+TypeScript, testable component; UI-02 작업함과 UI-03 시점 비교, UI-10 승인함을 먼저 구현.
- 멋진 UI보다 도메인 현업이 2분 내에 '왜 잘못됐는지' 파악할 수 있는 증거 뷰 우선.
- 빈 데이터, 실패/중단/취소, 미승인 자료, 권한 없음, stale CAS, 타 테넌트 구분 반드시 스토리북/테스트 추가.

**Gate 3 — AI 연동 및 회귀/실험**
- Langfuse 또는 Phoenix를 선택하되 버전/라이선스/온프레미스 가능 여부 확인. 무의미한 자체 tracing 중복 금지.
- LLM provider adapter는 예산/timeout/취소/PII masking을 통과한 경우에만 활성화. fallback은 참조 규칙과 합성 결과 재생.
- B2 경쟁군 포함 네 구성 비교; 같은 golden cases/모델/평가자/데이터 스냅샷.

**Gate 4 — 보안·감사·도메인 팩 검증**
- 승인 분리 SoD, revision CAS, RLS/tenant, 서명/외부 audit anchor, revoke/replay, fault injection; mock 신분만으로 auth 있다고 표시 금지.
- 공통 코어 변경 없이 Aurora손보·Horizon생명 pack 2개를 E2E로 성공시킨다.

**Gate 5 — 포트폴리오**
- 공개 합성 도메인 demo, README, 스크린샷, 2분 영상, 정량 실험 원시 CSV, 반례/한계, 재현 명령.
- 360 사례는 목표이며 실제 구축·정답검수 후에만 결과라고 표현한다.

## 작업마다 필수 출력

1. 수정 파일 경로·요구사항 ID·행동 변화
2. 실행한 정확한 테스트 명령과 요약, 실패 스택/중단 원인
3. 구현하지 않은 항목과 105점 루브릭의 증거 상태
4. 깨진 호환성/보안/비용 위험
5. 다음 작업 1개(많은 일을 동시에 벌리지 말 것)

## 금지

- 프로덕션 보험사 규정·약관을 임의로 추측, 고객 지급 자동결정.
- 데이터/성능/직원 인터뷰/실배포가 없는데 숫자나 완료 보고 허위 작성.
- 인터넷 검색 내용을 출처 없이 정본처럼 복사.
- 서버 승인 없이 클라이언트 state만으로 release APPROVED로 변경.
- LLM의 confidence만으로 최종 PASS 처리.
- 처음부터 Kubernetes/GraphDB/마이크로서비스 강제 도입.
