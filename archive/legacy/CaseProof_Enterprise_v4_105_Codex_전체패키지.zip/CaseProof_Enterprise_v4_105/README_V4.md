# CaseProof Enterprise v4.0 — 105점 목표 실무 설계·참조 구현 패키지

**상태 요약: 76/100 + 초과성과 0/5 = 76/105 (자체 증거 평가). 목표 105/105. 실제 금융사 배포/법규 인증/AI 모델 검증 미완료.**

## 먼저 읽을 문서

1. `specs/11_PRODUCT_BLUEPRINT_105.md` — 제품 핵심 정의·다보험사 업무팩·ADR·성공 정의.
2. `specs/12_WORKFLOWS_SCREEN_STATES.md` — 7개 현업 역할, 실무 흐름, 13개 화면, 실패·권한 상태.
3. `specs/13_DATA_API_CONSISTENCY.md` — 10개 불변식, DB/새 API 제안, 멱등성, 이벤트, 시점.
4. `security/14_THREAT_MODEL_CONTROLS.md` — 위험 14개, red-team 시나리오, PII·사고 대응.
5. `pilot/15_EXPERIMENT_PROTOCOL.md` — B0/B1/B2/T 공정 비교와 목표 360건, 통계 정의.
6. `score/16_RUBRIC_105.md` — 100점+5점, 항목별 증거·차단 게이트.
7. `pilot/17_RECRUITER_DEMO_AND_ROI.md` — 취업 면접 시연·비즈니스 가설·ROI.
8. `prompts/CODEX_V4_EXECUTION_MASTER.md` — Codex에 전달할 구현 순서와 완료 조건.

## 이전 버전과의 관계

- `docs/01~10`: v3 도메인·계약·실험 배경자료. 충돌 시 v4 문서가 **설계 정책상 우선**, 기존 API/SQL은 구 버전 제안 초안.
- `contracts/openapi.v1.yaml`/`core.sql`: 실제 서비스 동작을 뜻하지 않는 초기 계약. v4 계약이 확정되기 전에는 신규 설계표와 충돌을 표시할 것.
- `reference/`, `datasets/`, `tests/`: 표준 라이브러리로 작동하는 작은 **합성 결정론 참조 코드**; AI 서버·웹 UI·PostgreSQL이 구현됐다는 뜻이 아니다.
- `printable/`: 과거 버전 문서가 남을 수 있으므로 파일명 v3의 출력물은 **과거 보존용**. 최종 v4 문서는 zip 바깥에서 함께 제공.

## 지금 재현할 수 있는 것

```bash
cd CaseProof_Enterprise_v4_105
python -m unittest discover -s tests -v
python reference/verify_v3_fixture.py
python -m reference.demo
python reference/check_contracts.py
```

## v4에서 새로 구현한 참조 안전장치

- `governance.py`: 권한·회사 경계·수정자/승인자 분리·stale revision 차단.
- `evidence_pack.py`: 재현 가능한 SHA-256 manifest·인메모리 감사 체인 검증(불변성/전자서명 아님).
- `paired_benchmark.py`: 동일 데이터/평가자 버전 조건 검사, 신규 CRITICAL·미완료 차단, Wilson 구간.
- `test_v4_controls.py`: 위 함수에 대한 권한·경계·변조·회귀 음성 테스트.

**주의:** 외부 업체 AI 평가엔진 대비 우월성은 미측정; 이 패키지의 가상 보험규칙은 실제 상품이나 고객 의사결정에 사용할 수 없다.

## 직접 조작해 보는 오프라인 UI

`demo/CaseProof_Enterprise_오프라인_UI_시연.html` 파일을 브라우저에서 열면 가상 보험규정에 대한 AI 오류 발견→정정→상품 담당 검토→IT 승인자 최종 데모 승인→감사 이력의 **클릭 가능한 시뮬레이션**을 실행할 수 있다. 계정 선택은 UI 모형일 뿐 보안 인증이 아니다. 실제 서버, 데이터베이스, AI API와 연결되어 있지 않다. Chromium으로 기본 사용 흐름을 시험한 결과는 `evidence/STATUS_V4.md`에 기록.
